
export const LOGO_URL = "https://i.postimg.cc/T1TYjsVd/download-2-removebg-preview.png";

export const COLORS = {
  primary: "#0b57d0", // The deep blue from the "Next" button
  inputBg: "#e8f0fe", // The light blueish background for the input
  border: "#747775",
  textMuted: "#444746",
};
